let history = [];

async function send() {
  const input = document.getElementById("input");
  const text  = input.value.trim();
  if (!text) return;
  input.value = "";

  append("user", text);
  history.push([text, null]);

  const res = await fetch("/chat", {
    method: "POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify({prompt: text, history})
  });
  const d = await res.json();
  history = d.history;
  append("bot", d.reply);
}

function append(role, txt) {
  const box = document.getElementById("messages");
  const div = document.createElement("div");
  div.className = `msg ${role}`;
  div.innerText = txt;
  box.appendChild(div);
  box.scrollTop = box.scrollHeight;
}

document.getElementById("send").onclick = send;
document.getElementById("input")
        .addEventListener("keypress", e => { if (e.key==="Enter") send(); });
